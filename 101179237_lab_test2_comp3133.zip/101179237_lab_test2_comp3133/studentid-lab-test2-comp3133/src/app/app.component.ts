import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.styl']
})
export class AppComponent {

  title = 'studentid-lab-test2-comp3133';
  currMission: any = ""

  setCurrMission(mission: any) {
    this.currMission = mission
  }
}
