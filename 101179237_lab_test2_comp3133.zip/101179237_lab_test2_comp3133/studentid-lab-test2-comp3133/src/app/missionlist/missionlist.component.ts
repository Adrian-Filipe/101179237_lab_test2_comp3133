import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-missionlist',
  templateUrl: './missionlist.component.html',
  styleUrls: ['./missionlist.component.css']
})
export class MissionlistComponent implements OnInit {

  missionsList: any[] = []
  @Output() sendMission = new EventEmitter()

  constructor() {
    this.getData()
  }

  getData() {
    fetch("https://api.spacexdata.com/v3/launches")
    .then(resp => resp.json())
    .then(resp => {
      for (let i = 0; i < resp.length; i++){
        // this.missionsList.push([i, resp[i].mission_name, resp[i].launch_year, resp[i].details, resp[i].links.mission_patch_small]);
        this.missionsList.push(resp[i])
      }
    }).catch(err => {

    })
  }

  getMission(mission: any) {
    this.sendMission.emit(mission)
  }

  ngOnInit(): void {
  }

}
