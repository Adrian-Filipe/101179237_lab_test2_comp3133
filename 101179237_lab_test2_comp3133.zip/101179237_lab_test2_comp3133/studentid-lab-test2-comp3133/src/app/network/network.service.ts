import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NetworkService {

  missionsList: any[] = []

  constructor() {
    this.getData()
  }

  getData() {
    fetch("https://api.spacexdata.com/v3/launches")
    .then(resp => resp.json())
    .then(resp => {
      for (let i = 0; i < resp.length; i++){
        this.missionsList.push([resp[i].mission_name, resp[i].launch_year, resp[i].details, resp[i].mission_patch_small]);
      }
    }).catch(err => {

    })
  }
}
